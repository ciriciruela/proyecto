var video, btnestado, seekslider, tiempoActual, duracionVideo,boton1,boton2,sonido,
fullscreen, prueba, prueba2,prueba22, estadoPantalla;

function inicializar(){
    
    estadoPantalla = false;
    prueba22 = document.querySelector(".btn_reproductor");
    prueba2 = document.querySelector(".principal");
    prueba = document.getElementById("video_principal");
    video = document.getElementById("video");
    btnestado = document.getElementById("reproducir");
    seekslider = document.getElementById("seekslider");
    tiempoActual = document.getElementById("tiempoActual");
    duracionVideo = document.getElementById("duracionVideo");
    //boton1 = document.getElementById("boton1");
    //boton2 = document.getElementById("boton2");
    sonido = document.getElementById("sonido");
    fullscreen = document.getElementById("screen");
    seektimeupdate();
    btnestado.addEventListener("click",estadoVideo,false);
    seekslider.addEventListener("change",videoSeek,false);
    video.addEventListener("timeupdate",seektimeupdate,false);
    //boton1.addEventListener("click", cambiarVideo, false);
    //boton2.addEventListener("click", cambiarVideo, false);
    
    sonido.addEventListener("click", function(){

      if(video.muted){
        video.muted = false;
        sonido.src = "img-videos/icon-audio.png";
      }
      else{
        video.muted = true;
        sonido.src = "img-videos/icon-audio1.png";
      }
    },false);

    fullscreen.addEventListener("click", function(){
    
      if(prueba2.requestFullScreen){       
        
        if(estadoPantalla == false){
              prueba2.requestFullScreen();
              estadoPantalla = true;
              CambiarEstilos(estadoPantalla);
              
          }
          else{
              
              document.CancelFullScreen();
              estadoPantalla = false;
              CambiarEstilos(estadoPantalla);
          }
          
      }
      else if (prueba2.webkitRequestFullScreen) {
          
          if(estadoPantalla == false){
              prueba2.webkitRequestFullScreen();
              estadoPantalla = true;
              CambiarEstilos(estadoPantalla);
              
          }
          else{
              
              document.webkitCancelFullScreen();
              estadoPantalla = false;
              CambiarEstilos(estadoPantalla);
          }
        
      }
      else if (prueba2.mozRequestFullScreen) {
        
        if(estadoPantalla == false){
              prueba2.mozRequestFullScreen();
              estadoPantalla = true;
              CambiarEstilos(estadoPantalla);
              
          }
          else{
              
              document.mozCancelFullScreen();
              estadoPantalla = false;
              CambiarEstilos(estadoPantalla);
          }

      }
        else if (prueba2.msRequestFullScreen) {
        
        if(estadoPantalla == false){
              prueba2.msRequestFullScreen();
              estadoPantalla = true;
              CambiarEstilos(estadoPantalla);
              
          }
          else{
              
              document.msCancelFullScreen();
              estadoPantalla = false;
              CambiarEstilos(estadoPantalla);
          }

      }
    },false);
    
        document.addEventListener("fullscreenchange", function() {
         if(estadoPantalla == true){
                estadoPantalla = false;
            }else{
                estadoPantalla = true;
                $(prueba22).css({      
                "position": 'static',
                "bottom": 'auto',
                "left": 'auto',
                "right": 'auto'
                });
            }
        });
        document.addEventListener("mozfullscreenchange", function() {
         if(estadoPantalla == true){
                estadoPantalla = false;
            }else{
                estadoPantalla = true;
                $(prueba22).css({      
                "position": 'static',
                "bottom": 'auto',
                "left": 'auto',
                "right": 'auto'
                });
            }
        });
        document.addEventListener("webkitfullscreenchange", function() {
        
            if(estadoPantalla == true){
                estadoPantalla = false;
            }else{
                estadoPantalla = true;
                $(prueba22).css({      
                "position": 'static',
                "bottom": 'auto',
                "left": 'auto',
                "right": 'auto'
                });
            }
        });
        document.addEventListener("msfullscreenchange", function() {
         if(estadoPantalla == true){
                estadoPantalla = false;
            }else{
                estadoPantalla = true;
                $(prueba22).css({      
                "position": 'static',
                "bottom": 'auto',
                "left": 'auto',
                "right": 'auto'
                });
            }
        });
    
    $(video).click(function() {
    $(prueba22).toggle(1500);
    });
};


//Asigna valores y funciones a las variables
window.onload = inicializar;

function estadoVideo(){
    if(video.paused){
        video.play();
        document.getElementById("estado").src = "img-videos/icon-pause.png";
    }else{
        video.pause();
        document.getElementById("estado").src = "img-videos/icon-play.png";
    }
}

function videoSeek(){
    var seekto = video.duration * (seekslider.value /100);
    video.currentTime = seekto;
}

function seektimeupdate(){
    var nt = video.currentTime * (100/video.duration);
    seekslider.value = nt;
    var minutoActual = Math.floor(video.currentTime/60);
    var segundoActual = Math.floor(video.currentTime - minutoActual * 60);
    var duracionMinutos = Math.floor(video.duration / 60);
    var duracionSegundos = Math.floor(video.duration - duracionMinutos * 60);

    if(segundoActual < 10){
        segundoActual = "0" + segundoActual;
    }

    if(duracionSegundos < 10){
        duracionSegundos = "0" + duracionSegundos;
    }

    if(minutoActual < 10){
        minutoActual = "0" + minutoActual;
    }

    if(duracionMinutos < 10){
        duracionMinutos = "0" + duracionMinutos;
    }

    tiempoActual.innerHTML = minutoActual + ":" +segundoActual + "/";
    duracionVideo.innerHTML = duracionMinutos + ":" +duracionSegundos;
}

function cambiarVideo(e){

  if(e.target.id == "boton1"){
    video.src = "img-videos/luffyvsblueno.mp4";
    video.poster = "img-videos/imgcargando1.gif";
    setTimeout(PlayVideo,5000);
  }

  if(e.target.id == "boton2"){
    video.src = "img-videos/zoro.mp4";
    video.poster = "img-videos/imgcargando1.gif";
    setTimeout(PlayVideo,5000);
  }
}

function PlayVideo(){

    video.play();
    document.getElementById("estado").src = "img-videos/icon-pause.png";
}

function CambiarEstilos(estadoPantalla){
    
    if(estadoPantalla){
     $(prueba22).css({      
        "position": 'absolute',
        "bottom": '0',
        "left": '0',
        "right": '0'
    });
    }
    else{
        $(prueba22).css({      
        "position": 'static',
        "bottom": 'auto',
        "left": 'auto',
        "right": 'auto'
    });
    }
}

function ocultarControles() {
  
    
    $(prueba22).css({      
        "visibility": 'hidden'
    });
}
